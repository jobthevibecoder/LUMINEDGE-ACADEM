const calculatorModal = document.getElementById('calculatorModal');
const comingSoonModal = document.getElementById('comingSoonModal');
const aiResponseModal = document.getElementById('aiResponseModal');
const voiceButton = document.getElementById('voiceButton');
const assistantInput = document.getElementById('assistantInput');
const calcDisplay = document.getElementById('calcDisplay');
const aiResponseText = document.getElementById('aiResponseText');

let currentInput = '';

const mathOperations = {
  add: (a, b) => a + b,
  subtract: (a, b) => a - b,
  multiply: (a, b) => a * b,
  divide: (a, b) => a / b
};

function init() {
  if ('webkitSpeechRecognition' in window) {
    const recognition = new webkitSpeechRecognition();
    recognition.continuous = false;
    recognition.interimResults = false;

    voiceButton.addEventListener('click', () => {
      recognition.start();
      voiceButton.innerHTML = '<i class="fas fa-microphone-slash"></i>';
      voiceButton.style.backgroundColor = '#e74c3c';
    });

    recognition.onresult = (event) => {
      const transcript = event.results[0][0].transcript;
      assistantInput.value = transcript;
      voiceButton.innerHTML = '<i class="fas fa-microphone"></i>';
      voiceButton.style.backgroundColor = 'white';
      processMathQuery(transcript);
    };

    recognition.onerror = () => {
      voiceButton.innerHTML = '<i class="fas fa-microphone"></i>';
      voiceButton.style.backgroundColor = 'white';
    };

    recognition.onend = () => {
      voiceButton.innerHTML = '<i class="fas fa-microphone"></i>';
      voiceButton.style.backgroundColor = 'white';
    };
  } else {
    voiceButton.style.display = 'none';
  }

  assistantInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') {
      processMathQuery(assistantInput.value);
    }
  });
}

function processMathQuery(query) {
  assistantInput.value = '';
  const addMatch = query.match(/(\d+)\s*plus\s*(\d+)/i);
  const subtractMatch = query.match(/(\d+)\s*minus\s*(\d+)/i);
  const multiplyMatch = query.match(/(\d+)\s*times\s*(\d+)/i);
  const divideMatch = query.match(/(\d+)\s*divided by\s*(\d+)/i);

  if (addMatch) {
    const a = parseInt(addMatch[1]);
    const b = parseInt(addMatch[2]);
    showAIResponse(`${a} + ${b} = ${mathOperations.add(a, b)}`);
  } else if (subtractMatch) {
    const a = parseInt(subtractMatch[1]);
    const b = parseInt(subtractMatch[2]);
    showAIResponse(`${a} - ${b} = ${mathOperations.subtract(a, b)}`);
  } else if (multiplyMatch) {
    const a = parseInt(multiplyMatch[1]);
    const b = parseInt(multiplyMatch[2]);
    showAIResponse(`${a} × ${b} = ${mathOperations.multiply(a, b)}`);
  } else if (divideMatch) {
    const a = parseInt(divideMatch[1]);
    const b = parseInt(divideMatch[2]);
    showAIResponse(b === 0 ? "Error: Division by zero" : `${a} ÷ ${b} = ${mathOperations.divide(a, b)}`);
  } else {
    showAIResponse("Try asking: What is 5 plus 3?");
  }
}

function appendToDisplay(val) {
  currentInput += val;
  calcDisplay.value = currentInput;
}

function clearDisplay() {
  currentInput = '';
  calcDisplay.value = '';
}

function backspace() {
  currentInput = currentInput.slice(0, -1);
  calcDisplay.value = currentInput;
}

function calculate() {
  try {
    const result = eval(currentInput);
    currentInput = result.toString();
    calcDisplay.value = currentInput;
  } catch {
    calcDisplay.value = 'Error';
    currentInput = '';
  }
}

function openCalculator() {
  calculatorModal.style.display = 'flex';
}

function closeCalculator() {
  calculatorModal.style.display = 'none';
}

function showComingSoon() {
  comingSoonModal.style.display = 'flex';
}

function closeComingSoon() {
  comingSoonModal.style.display = 'none';
}

function showAIResponse(message) {
  aiResponseText.textContent = message;
  aiResponseModal.style.display = 'flex';
}

function closeAIResponse() {
  aiResponseModal.style.display = 'none';
}

document.addEventListener('DOMContentLoaded', init);

window.addEventListener('click', (event) => {
  if (event.target === calculatorModal) closeCalculator();
  if (event.target === comingSoonModal) closeComingSoon();
  if (event.target === aiResponseModal) closeAIResponse();
});
